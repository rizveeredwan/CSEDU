1.write any expression in in.txt file
2.output will be in out.txt file
3.give input with space separated
4.to run the code just run the script ./Assignment3  
