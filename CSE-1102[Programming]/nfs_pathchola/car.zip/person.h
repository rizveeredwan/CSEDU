void make_person(int x, int y);
void erase_person(int x,int y);