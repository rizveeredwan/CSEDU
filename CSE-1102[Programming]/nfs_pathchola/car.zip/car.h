void draw_car(int startx, int starty, int road, int lane, int color);
void erase_car(int startx, int starty, int road, int lane);
int lane_formatter(int road, int lane);
void tilt_car(int croad, int clane, int color);